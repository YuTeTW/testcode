let solutionData = {
    selectflag : 1,
    taggedSolutionInfoText : "",
    solutionName : "OLEUM",
    density_coefficient : [2162.0000000000000, 360.00000000000000, 0.0000000000000000, -1.1000000000000001],
    heatCapacity_coefficient : [13330.000000000000, 485.69999999999999, 0.0000000000000000],
    hazHeatOfVaporization_coefficient : [712756.00000000000, 0.0000000000000000, 0.0000000000000000],
    nonHazHeatOfVaporization_coefficient : [0.0000000000000000, 0.0000000000000000, 0.0000000000000000],
    molWtOfNonHazardousComponent : 0,
    minimumAllowedStrengthPercent : 4,
    maximiumAllowedStrengthPercent : 65,    
    hazPartialPressureTable : {
        pressureUnitsInFile : 43,
        numRows : 10,
        numColumns : 8,  
        tableValues : [
    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 15.862033483404163,
     hazardousComponentMassFraction : 0.033700000000000001,
     temperatureKelvin : 283.14999999999998
    },

    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 26.818954957344985,
     hazardousComponentMassFraction : 0.033700000000000001,
     temperatureKelvin : 293.14999999999998
    },

    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 43.800322275962337,
     hazardousComponentMassFraction : 0.033700000000000001,
     temperatureKelvin : 303.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 0.52000000000000002,
     partialPressureInPascals : 69.327699999999993,
     hazardousComponentMassFraction : 0.033700000000000001,
     temperatureKelvin : 313.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 0.80000000000000004,
     partialPressureInPascals : 106.65800000000000,
     hazardousComponentMassFraction : 0.033700000000000001,
     temperatureKelvin : 323.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 1.3300000000000001,
     partialPressureInPascals : 177.31892500000001,
     hazardousComponentMassFraction : 0.033700000000000001,
     temperatureKelvin : 333.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 2.2500000000000000,
     partialPressureInPascals : 299.97562499999998,
     hazardousComponentMassFraction : 0.033700000000000001,
     temperatureKelvin : 343.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 3.8199999999999998,
     partialPressureInPascals : 509.29194999999993,
     hazardousComponentMassFraction : 0.033700000000000001,
     temperatureKelvin : 353.14999999999998
    },

    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 24.482087116527460,
     hazardousComponentMassFraction : 0.086899999999999991,
     temperatureKelvin : 283.14999999999998
    },

    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 46.310341825605271,
     hazardousComponentMassFraction : 0.086899999999999991,
     temperatureKelvin : 293.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 0.63000000000000000,
     partialPressureInPascals : 83.993174999999994,
     hazardousComponentMassFraction : 0.086899999999999991,
     temperatureKelvin : 303.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 1.1000000000000001,
     partialPressureInPascals : 146.65475000000001,
     hazardousComponentMassFraction : 0.086899999999999991,
     temperatureKelvin : 313.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 2.0099999999999998,
     partialPressureInPascals : 267.97822499999995,
     hazardousComponentMassFraction : 0.086899999999999991,
     temperatureKelvin : 323.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 3.6499999999999999,
     partialPressureInPascals : 486.62712499999998,
     hazardousComponentMassFraction : 0.086899999999999991,
     temperatureKelvin : 333.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 6.4000000000000004,
     partialPressureInPascals : 853.26400000000001,
     hazardousComponentMassFraction : 0.086899999999999991,
     temperatureKelvin : 343.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 11.199999999999999,
     partialPressureInPascals : 1493.2119999999998,
     hazardousComponentMassFraction : 0.086899999999999991,
     temperatureKelvin : 353.14999999999998
    },

    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 56.639766167582657,
     hazardousComponentMassFraction : 0.17800000000000002,
     temperatureKelvin : 283.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 0.81000000000000005,
     partialPressureInPascals : 107.99122500000000,
     hazardousComponentMassFraction : 0.17800000000000002,
     temperatureKelvin : 293.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 1.4800000000000000,
     partialPressureInPascals : 197.31729999999999,
     hazardousComponentMassFraction : 0.17800000000000002,
     temperatureKelvin : 303.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 2.8500000000000001,
     partialPressureInPascals : 379.96912499999996,
     hazardousComponentMassFraction : 0.17800000000000002,
     temperatureKelvin : 313.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 5.5000000000000000,
     partialPressureInPascals : 733.27374999999995,
     hazardousComponentMassFraction : 0.17800000000000002,
     temperatureKelvin : 323.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 10.400000000000000,
     partialPressureInPascals : 1386.5539999999999,
     hazardousComponentMassFraction : 0.17800000000000002,
     temperatureKelvin : 333.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 18.500000000000000,
     partialPressureInPascals : 2466.4662499999999,
     hazardousComponentMassFraction : 0.17800000000000002,
     temperatureKelvin : 343.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 32.299999999999997,
     partialPressureInPascals : 4306.3167499999990,
     hazardousComponentMassFraction : 0.17800000000000002,
     temperatureKelvin : 353.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 0.48999999999999999,
     partialPressureInPascals : 65.328024999999997,
     hazardousComponentMassFraction : 0.22800000000000001,
     temperatureKelvin : 283.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 1.1899999999999999,
     partialPressureInPascals : 158.65377500000000,
     hazardousComponentMassFraction : 0.22800000000000001,
     temperatureKelvin : 293.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 2.2700000000000000,
     partialPressureInPascals : 302.64207499999998,
     hazardousComponentMassFraction : 0.22800000000000001,
     temperatureKelvin : 303.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 4.6299999999999999,
     partialPressureInPascals : 617.28317499999991,
     hazardousComponentMassFraction : 0.22800000000000001,
     temperatureKelvin : 313.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 8.9499999999999993,
     partialPressureInPascals : 1193.2363749999997,
     hazardousComponentMassFraction : 0.22800000000000001,
     temperatureKelvin : 323.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 17.100000000000001,
     partialPressureInPascals : 2279.8147500000000,
     hazardousComponentMassFraction : 0.22800000000000001,
     temperatureKelvin : 333.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 31.399999999999999,
     partialPressureInPascals : 4186.3264999999992,
     hazardousComponentMassFraction : 0.22800000000000001,
     temperatureKelvin : 343.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 56.600000000000001,
     partialPressureInPascals : 7546.0535000000000,
     hazardousComponentMassFraction : 0.22800000000000001,
     temperatureKelvin : 353.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 0.62000000000000000,
     partialPressureInPascals : 82.659949999999995,
     hazardousComponentMassFraction : 0.26700000000000002,
     temperatureKelvin : 283.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 1.4700000000000000,
     partialPressureInPascals : 195.98407499999999,
     hazardousComponentMassFraction : 0.26700000000000002,
     temperatureKelvin : 293.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 3.4300000000000002,
     partialPressureInPascals : 457.29617500000001,
     hazardousComponentMassFraction : 0.26700000000000002,
     temperatureKelvin : 303.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 6.6500000000000004,
     partialPressureInPascals : 886.59462499999995,
     hazardousComponentMassFraction : 0.26700000000000002,
     temperatureKelvin : 313.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 13.100000000000000,
     partialPressureInPascals : 1746.5247499999998,
     hazardousComponentMassFraction : 0.26700000000000002,
     temperatureKelvin : 323.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 26.699999999999999,
     partialPressureInPascals : 3559.7107499999997,
     hazardousComponentMassFraction : 0.26700000000000002,
     temperatureKelvin : 333.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 49.200000000000003,
     partialPressureInPascals : 6559.4669999999996,
     hazardousComponentMassFraction : 0.26700000000000002,
     temperatureKelvin : 343.14999999999998
    },

    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 11675.860657862724,
     hazardousComponentMassFraction : 0.26700000000000002,
     temperatureKelvin : 353.14999999999998
    },

    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 130.05728831801093,
     hazardousComponentMassFraction : 0.30199999999999999,
     temperatureKelvin : 283.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 2.1800000000000002,
     partialPressureInPascals : 290.64305000000002,
     hazardousComponentMassFraction : 0.30199999999999999,
     temperatureKelvin : 293.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 4.6200000000000001,
     partialPressureInPascals : 615.94994999999994,
     hazardousComponentMassFraction : 0.30199999999999999,
     temperatureKelvin : 303.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 9.3399999999999999,
     partialPressureInPascals : 1245.2321499999998,
     hazardousComponentMassFraction : 0.30199999999999999,
     temperatureKelvin : 313.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 18.899999999999999,
     partialPressureInPascals : 2519.7952499999997,
     hazardousComponentMassFraction : 0.30199999999999999,
     temperatureKelvin : 323.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 36.799999999999997,
     partialPressureInPascals : 4906.2679999999991,
     hazardousComponentMassFraction : 0.30199999999999999,
     temperatureKelvin : 333.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 67.200000000000003,
     partialPressureInPascals : 8959.2719999999990,
     hazardousComponentMassFraction : 0.30199999999999999,
     temperatureKelvin : 343.14999999999998
    },

    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 15811.875646543953,
     hazardousComponentMassFraction : 0.30199999999999999,
     temperatureKelvin : 353.14999999999998
    },

    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 475.83810681551591,
     hazardousComponentMassFraction : 0.34000000000000002,
     temperatureKelvin : 283.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 5.4000000000000004,
     partialPressureInPascals : 719.94150000000002,
     hazardousComponentMassFraction : 0.34000000000000002,
     temperatureKelvin : 293.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 7.9500000000000002,
     partialPressureInPascals : 1059.9138750000000,
     hazardousComponentMassFraction : 0.34000000000000002,
     temperatureKelvin : 303.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 16.300000000000001,
     partialPressureInPascals : 2173.1567500000001,
     hazardousComponentMassFraction : 0.34000000000000002,
     temperatureKelvin : 313.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 32.100000000000001,
     partialPressureInPascals : 4279.6522500000001,
     hazardousComponentMassFraction : 0.34000000000000002,
     temperatureKelvin : 323.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 60.200000000000003,
     partialPressureInPascals : 8026.0145000000002,
     hazardousComponentMassFraction : 0.34000000000000002,
     temperatureKelvin : 333.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 109.59999999999999,
     partialPressureInPascals : 14612.145999999999,
     hazardousComponentMassFraction : 0.34000000000000002,
     temperatureKelvin : 343.14999999999998
    },

    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 25715.283788310153,
     hazardousComponentMassFraction : 0.34000000000000002,
     temperatureKelvin : 353.14999999999998
    },

    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 1636.4753662832513,
     hazardousComponentMassFraction : 0.49570000000000003,
     temperatureKelvin : 283.14999999999998
    },

    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 3442.9462099251714,
     hazardousComponentMassFraction : 0.49570000000000003,
     temperatureKelvin : 293.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 51.729300000000002,
     partialPressureInPascals : 6896.6795992500001,
     hazardousComponentMassFraction : 0.49570000000000003,
     temperatureKelvin : 303.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 99.123599999999996,
     partialPressureInPascals : 13215.406160999999,
     hazardousComponentMassFraction : 0.49570000000000003,
     temperatureKelvin : 313.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 179.35599999999999,
     partialPressureInPascals : 23912.190309999998,
     hazardousComponentMassFraction : 0.49570000000000003,
     temperatureKelvin : 323.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 308.38299999999998,
     partialPressureInPascals : 41114.392517499997,
     hazardousComponentMassFraction : 0.49570000000000003,
     temperatureKelvin : 333.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 506.64100000000002,
     partialPressureInPascals : 67546.644722500001,
     hazardousComponentMassFraction : 0.49570000000000003,
     temperatureKelvin : 343.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 799.19799999999998,
     partialPressureInPascals : 106551.07535499999,
     hazardousComponentMassFraction : 0.49570000000000003,
     temperatureKelvin : 353.14999999999998
    },

    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 5111.1043983969657,
     hazardousComponentMassFraction : 0.58530000000000004,
     temperatureKelvin : 283.14999999999998
    },

    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 9870.5035843585429,
     hazardousComponentMassFraction : 0.58530000000000004,
     temperatureKelvin : 293.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 136.90000000000001,
     partialPressureInPascals : 18251.850250000000,
     hazardousComponentMassFraction : 0.58530000000000004,
     temperatureKelvin : 303.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 243.40000000000001,
     partialPressureInPascals : 32450.696499999998,
     hazardousComponentMassFraction : 0.58530000000000004,
     temperatureKelvin : 313.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 410.39999999999998,
     partialPressureInPascals : 54715.553999999996,
     hazardousComponentMassFraction : 0.58530000000000004,
     temperatureKelvin : 323.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 660.60000000000002,
     partialPressureInPascals : 88072.843500000003,
     hazardousComponentMassFraction : 0.58530000000000004,
     temperatureKelvin : 333.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 1020.5000000000000,
     partialPressureInPascals : 136055.61124999999,
     hazardousComponentMassFraction : 0.58530000000000004,
     temperatureKelvin : 343.14999999999998
    },

    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 205066.32164377868,
     hazardousComponentMassFraction : 0.58530000000000004,
     temperatureKelvin : 353.14999999999998
    },

    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 6533.6595138326611,
     hazardousComponentMassFraction : 0.64920000000000000,
     temperatureKelvin : 283.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 101.30000000000000,
     partialPressureInPascals : 13505.569249999999,
     hazardousComponentMassFraction : 0.64920000000000000,
     temperatureKelvin : 293.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 199.59999999999999,
     partialPressureInPascals : 26611.170999999998,
     hazardousComponentMassFraction : 0.64920000000000000,
     temperatureKelvin : 303.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 360.80000000000001,
     partialPressureInPascals : 48102.758000000002,
     hazardousComponentMassFraction : 0.64920000000000000,
     temperatureKelvin : 313.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 607.10000000000002,
     partialPressureInPascals : 80940.089749999999,
     hazardousComponentMassFraction : 0.64920000000000000,
     temperatureKelvin : 323.14999999999998
    },

    {
     valueIsListedInFile : 1,
     pressureValueAsListedInFile : 962.89999999999998,
     partialPressureInPascals : 128376.23524999998,
     hazardousComponentMassFraction : 0.64920000000000000,
     temperatureKelvin : 333.14999999999998
    },

    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 198212.10469517161,
     hazardousComponentMassFraction : 0.64920000000000000,
     temperatureKelvin : 343.14999999999998
    },

    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 298601.59142138035,
     hazardousComponentMassFraction : 0.64920000000000000,
     temperatureKelvin : 353.14999999999998
    }
   ]
    },
    nonHazPartialPressureTable : {
        pressureUnitsInFile : 43,
        numRows : 1,
        numColumns : 1,        
        tableValues : [
    {
     valueIsListedInFile : 0,
     pressureValueAsListedInFile : 0.0000000000000000,
     partialPressureInPascals : 9.9999999999999998e-201,
     hazardousComponentMassFraction : 1.0000000000000000,
     temperatureKelvin : 273.14999999999998
    }
    ]
    },
    totalVaporPressureTable : {
        pressureUnitsInFile : 0,
        numRows : 0,
        numColumns : 0,
        tableValues : {
        }
    },
    hazardousComponentPercentage : {
        DataRefCon : 0,
        DataAvailFlag : 0,
        UserInStr : "0",
        UserUnits : 0,
        CompValue : 0,
        new_noLongerUsed : 0
    }        
}